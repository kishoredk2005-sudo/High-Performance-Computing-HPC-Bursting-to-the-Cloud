from setuptools import setup, find_packages

setup(
    name="hpc-cloud-burst",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "boto3>=1.34.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "hpc-burst=hpc_burst.cli:main",
        ],
    },
    python_requires=">=3.9",
)
