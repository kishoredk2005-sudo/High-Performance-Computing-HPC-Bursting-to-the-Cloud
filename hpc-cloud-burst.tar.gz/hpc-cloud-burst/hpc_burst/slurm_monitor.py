"""
Slurm cluster monitoring — detects when on-premise capacity is exhausted.
Parses squeue/sinfo output to determine cluster utilization.
"""

import subprocess
import logging
import re
from dataclasses import dataclass
from typing import List, Tuple

from hpc_burst.config import SlurmConfig

logger = logging.getLogger(__name__)


@dataclass
class ClusterStatus:
    total_cores: int
    used_cores: int
    pending_jobs: int
    running_jobs: int
    utilization: float  # 0.0 - 1.0
    pending_job_ids: List[str]


def run_cmd(cmd: List[str], timeout: int = 30) -> str:
    """Execute a shell command and return stdout."""
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {' '.join(cmd)}\nstderr: {e.stderr}")
        raise
    except FileNotFoundError:
        logger.error(f"Command not found: {cmd[0]}")
        raise


def get_cluster_status(cfg: SlurmConfig) -> ClusterStatus:
    """Query Slurm to get current cluster utilization."""

    # Get node info: total cores and allocated cores
    # sinfo -N -h -o "%n %C" gives: nodename  allocated/idle/other/total
    sinfo_out = run_cmd([
        cfg.sinfo_path, "-N", "-h",
        "--partition", cfg.partition_name if False else "",  # all partitions for on-prem
        "-o", "%C"
    ])

    total_cores = 0
    used_cores = 0

    # Output format: ALLOCATED/IDLE/OTHER/TOTAL (aggregated)
    for line in sinfo_out.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        match = re.match(r"(\d+)/(\d+)/(\d+)/(\d+)", line)
        if match:
            alloc, idle, other, total = map(int, match.groups())
            total_cores = total
            used_cores = alloc
            break

    # Get job counts
    # squeue -h -o "%T %i" gives: STATE JOBID
    squeue_out = run_cmd([cfg.squeue_path, "-h", "-o", "%T %i"])

    running_jobs = 0
    pending_jobs = 0
    pending_job_ids = []

    for line in squeue_out.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            state, job_id = parts[0], parts[1]
            if state == "RUNNING":
                running_jobs += 1
            elif state == "PENDING":
                pending_jobs += 1
                pending_job_ids.append(job_id)

    utilization = used_cores / total_cores if total_cores > 0 else 0.0

    status = ClusterStatus(
        total_cores=total_cores,
        used_cores=used_cores,
        pending_jobs=pending_jobs,
        running_jobs=running_jobs,
        utilization=utilization,
        pending_job_ids=pending_job_ids,
    )

    logger.info(
        f"Cluster status: {used_cores}/{total_cores} cores "
        f"({utilization:.0%}), {running_jobs} running, {pending_jobs} pending"
    )

    return status


def should_burst(cfg: SlurmConfig, status: ClusterStatus) -> bool:
    """Determine if cloud bursting should be triggered."""
    if status.pending_jobs == 0:
        return False

    if status.utilization >= cfg.capacity_threshold:
        logger.warning(
            f"Burst condition met: utilization {status.utilization:.0%} "
            f">= threshold {cfg.capacity_threshold:.0%} "
            f"with {status.pending_jobs} pending jobs"
        )
        return True

    return False


def get_pending_job_details(cfg: SlurmConfig, job_id: str) -> dict:
    """Get detailed info about a pending job for cloud execution."""
    out = run_cmd([
        cfg.scontrol_path, "show", "job", job_id
    ])

    details = {}
    for line in out.split("\n"):
        for pair in line.strip().split():
            if "=" in pair:
                key, _, val = pair.partition("=")
                details[key] = val

    return {
        "job_id": job_id,
        "name": details.get("JobName", "unknown"),
        "num_cpus": int(details.get("NumCPUs", "1")),
        "num_nodes": int(details.get("NumNodes", "1")),
        "work_dir": details.get("WorkDir", "/tmp"),
        "command": details.get("Command", ""),
        "time_limit": details.get("TimeLimit", "UNLIMITED"),
        "submit_time": details.get("SubmitTime", ""),
    }
