"""
Main orchestrator — coordinates the full cloud burst lifecycle:
1. Monitor Slurm cluster utilization
2. Detect burst condition
3. Provision cloud nodes
4. Transfer data
5. Execute job
6. Return results
7. Tear down cloud resources
"""

import os
import json
import time
import logging
from datetime import datetime
from typing import Optional

from hpc_burst.config import BurstConfig, load_config
from hpc_burst.slurm_monitor import (
    get_cluster_status, should_burst, get_pending_job_details
)
from hpc_burst.cloud_provisioner import (
    provision_instances, wait_for_ssh, terminate_instances,
    find_burst_instances, CloudInstance
)
from hpc_burst.data_transfer import (
    transfer_to_cloud, transfer_from_cloud, cleanup_s3
)
from hpc_burst.job_runner import submit_and_wait, execute_direct

logger = logging.getLogger(__name__)


class BurstOrchestrator:
    """Orchestrates the full HPC cloud burst lifecycle."""

    def __init__(self, config_path: str = "/etc/hpc-burst/config.yaml"):
        self.cfg = load_config(config_path)
        self._setup_logging()
        self._ensure_state_dir()

    def _setup_logging(self):
        logging.basicConfig(
            level=getattr(logging, self.cfg.log_level.upper(), logging.INFO),
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    def _ensure_state_dir(self):
        os.makedirs(self.cfg.state_dir, exist_ok=True)

    def run_monitor_loop(self, poll_interval: int = 30):
        """Continuously monitor and burst as needed."""
        logger.info("HPC Cloud Burst monitor started")
        logger.info(f"Burst threshold: {self.cfg.slurm.capacity_threshold:.0%}")
        logger.info(f"Max cloud nodes: {self.cfg.max_cloud_nodes}")

        while True:
            try:
                self._check_and_burst()
            except KeyboardInterrupt:
                logger.info("Monitor stopped by user")
                break
            except Exception as e:
                logger.error(f"Monitor loop error: {e}", exc_info=True)

            time.sleep(poll_interval)

    def _check_and_burst(self):
        """Single check-and-burst cycle."""
        status = get_cluster_status(self.cfg.slurm)

        if not should_burst(self.cfg.slurm, status):
            return

        # Check how many cloud nodes already exist
        existing = find_burst_instances(self.cfg.aws)
        if len(existing) >= self.cfg.max_cloud_nodes:
            logger.warning(
                f"Max cloud nodes reached ({len(existing)}/{self.cfg.max_cloud_nodes})"
            )
            return

        # Process pending jobs
        for job_id in status.pending_job_ids:
            if len(find_burst_instances(self.cfg.aws)) >= self.cfg.max_cloud_nodes:
                break
            self.burst_job(job_id)

    def burst_job(self, job_id: str) -> bool:
        """Execute full burst lifecycle for a single job."""
        burst_id = f"burst-{job_id}-{int(time.time())}"
        logger.info(f"=== Starting cloud burst: {burst_id} ===")

        state = {"burst_id": burst_id, "job_id": job_id, "phase": "init"}
        self._save_state(burst_id, state)

        instances = []
        try:
            # 1. Get job details
            job = get_pending_job_details(self.cfg.slurm, job_id)
            logger.info(f"Job: {job['name']}, CPUs: {job['num_cpus']}, Nodes: {job['num_nodes']}")
            state["job_details"] = job
            state["phase"] = "provisioning"
            self._save_state(burst_id, state)

            # 2. Provision cloud nodes
            instances = provision_instances(
                self.cfg.aws,
                count=job["num_nodes"],
                required_cpus_per_node=job["num_cpus"] // max(job["num_nodes"], 1),
                job_id=job_id,
            )
            state["instances"] = [i.instance_id for i in instances]
            state["phase"] = "waiting_ssh"
            self._save_state(burst_id, state)

            # 3. Wait for SSH
            if not wait_for_ssh(instances):
                raise RuntimeError("SSH not available on cloud nodes")

            state["phase"] = "transferring_data"
            self._save_state(burst_id, state)

            # 4. Transfer data to cloud
            primary = instances[0]
            work_dir = job["work_dir"]
            remote_dir = f"/scratch/burst/{job_id}"

            success = transfer_to_cloud(
                self.cfg.transfer, work_dir, primary.public_ip, remote_dir
            )
            if not success:
                raise RuntimeError("Data transfer to cloud failed")

            state["phase"] = "executing"
            self._save_state(burst_id, state)

            # 5. Execute job
            job_script = job.get("command", "")
            if job_script and job_script.endswith(".sh"):
                success = submit_and_wait(
                    self.cfg.transfer, primary, job_script, remote_dir
                )
            else:
                success = execute_direct(
                    self.cfg.transfer, primary,
                    job_script or "echo 'No command specified'",
                    remote_dir,
                )
            if not success:
                raise RuntimeError("Job execution failed on cloud")

            state["phase"] = "returning_results"
            self._save_state(burst_id, state)

            # 6. Transfer results back
            results_dir = os.path.join(work_dir, "results")
            os.makedirs(results_dir, exist_ok=True)

            success = transfer_from_cloud(
                self.cfg.transfer, primary.public_ip,
                f"{remote_dir}/results", results_dir
            )
            if not success:
                logger.warning("Results transfer failed — data may still be on cloud")

            state["phase"] = "completed"
            state["completed_at"] = datetime.utcnow().isoformat()
            self._save_state(burst_id, state)

            logger.info(f"=== Cloud burst {burst_id} completed successfully ===")
            return True

        except Exception as e:
            logger.error(f"Burst {burst_id} failed: {e}", exc_info=True)
            state["phase"] = "failed"
            state["error"] = str(e)
            self._save_state(burst_id, state)
            return False

        finally:
            # 7. Tear down cloud resources
            self._teardown(instances, burst_id)

    def _teardown(self, instances: list, burst_id: str):
        """Clean up all cloud resources."""
        if not instances:
            return

        if self.cfg.teardown_delay_seconds > 0:
            logger.info(
                f"Waiting {self.cfg.teardown_delay_seconds}s before teardown..."
            )
            time.sleep(self.cfg.teardown_delay_seconds)

        instance_ids = [i.instance_id for i in instances]
        try:
            terminate_instances(self.cfg.aws, instance_ids)
        except Exception as e:
            logger.error(f"Teardown failed: {e}. Manual cleanup required for: {instance_ids}")

        # Clean up S3 if used
        cleanup_s3(self.cfg.transfer)

        logger.info(f"Teardown complete for {burst_id}")

    def cleanup_all(self):
        """Emergency cleanup: terminate ALL burst instances."""
        ids = find_burst_instances(self.cfg.aws)
        if ids:
            logger.warning(f"Emergency cleanup: terminating {len(ids)} instances")
            terminate_instances(self.cfg.aws, ids)
        else:
            logger.info("No burst instances found")

    def _save_state(self, burst_id: str, state: dict):
        """Persist burst state to disk for recovery."""
        path = os.path.join(self.cfg.state_dir, f"{burst_id}.json")
        with open(path, "w") as f:
            json.dump(state, f, indent=2, default=str)
