"""
Remote job execution on cloud burst nodes.
Handles SSH-based command execution and job monitoring.
"""

import os
import time
import subprocess
import logging
from typing import Optional

from hpc_burst.config import TransferConfig
from hpc_burst.cloud_provisioner import CloudInstance

logger = logging.getLogger(__name__)


def run_remote_command(
    cfg: TransferConfig,
    instance: CloudInstance,
    command: str,
    timeout: int = 3600,
    work_dir: Optional[str] = None,
) -> tuple[int, str, str]:
    """Execute a command on a remote cloud instance via SSH."""
    ssh_key = os.path.expanduser(cfg.ssh_key_path)
    host = instance.public_ip

    ssh_cmd = [
        "ssh",
        "-i", ssh_key,
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ConnectTimeout=30",
        f"{cfg.ssh_user}@{host}",
    ]

    if work_dir:
        command = f"cd {work_dir} && {command}"

    ssh_cmd.append(command)

    logger.info(f"Executing on {host}: {command}")

    try:
        result = subprocess.run(
            ssh_cmd, capture_output=True, text=True, timeout=timeout
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        logger.error(f"Remote command timed out after {timeout}s")
        return -1, "", "Timeout"


def submit_and_wait(
    cfg: TransferConfig,
    instance: CloudInstance,
    job_script: str,
    work_dir: str,
    poll_interval: int = 15,
    timeout: int = 14400,  # 4 hours
) -> bool:
    """Submit a Slurm job on the cloud node and wait for completion."""

    # Submit the job
    returncode, stdout, stderr = run_remote_command(
        cfg, instance,
        f"sbatch --parsable {job_script}",
        work_dir=work_dir,
    )

    if returncode != 0:
        logger.error(f"Failed to submit job: {stderr}")
        return False

    cloud_job_id = stdout.strip()
    logger.info(f"Cloud job submitted: {cloud_job_id}")

    # Poll for completion
    deadline = time.time() + timeout
    while time.time() < deadline:
        returncode, stdout, stderr = run_remote_command(
            cfg, instance,
            f"squeue -j {cloud_job_id} -h -o '%T' 2>/dev/null || echo 'UNKNOWN'",
        )

        state = stdout.strip()
        if not state or state in ("", "UNKNOWN"):
            # Job no longer in queue — check sacct
            returncode, stdout, stderr = run_remote_command(
                cfg, instance,
                f"sacct -j {cloud_job_id} -n -o State -X 2>/dev/null || echo 'COMPLETED'",
            )
            state = stdout.strip().split("\n")[0].strip()

            if state in ("COMPLETED", ""):
                logger.info(f"Cloud job {cloud_job_id} completed successfully")
                return True
            elif state in ("FAILED", "CANCELLED", "TIMEOUT", "NODE_FAIL"):
                logger.error(f"Cloud job {cloud_job_id} ended with state: {state}")
                return False

        logger.debug(f"Cloud job {cloud_job_id} state: {state}")
        time.sleep(poll_interval)

    logger.error(f"Cloud job {cloud_job_id} timed out after {timeout}s")
    return False


def execute_direct(
    cfg: TransferConfig,
    instance: CloudInstance,
    command: str,
    work_dir: str,
    timeout: int = 14400,
) -> bool:
    """Execute a command directly (non-Slurm) on the cloud node."""
    returncode, stdout, stderr = run_remote_command(
        cfg, instance, command, timeout=timeout, work_dir=work_dir
    )

    if returncode == 0:
        logger.info(f"Direct execution completed successfully")
        if stdout:
            logger.debug(f"stdout: {stdout[:500]}")
        return True
    else:
        logger.error(f"Direct execution failed (exit {returncode}): {stderr}")
        return False
