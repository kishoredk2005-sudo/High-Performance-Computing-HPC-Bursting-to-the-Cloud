"""
Secure data transfer between on-premise and cloud nodes.
Supports rsync over SSH and S3-based transfers.
"""

import os
import subprocess
import logging
from typing import List

import boto3
from botocore.exceptions import ClientError

from hpc_burst.config import TransferConfig

logger = logging.getLogger(__name__)


def transfer_to_cloud(
    cfg: TransferConfig,
    source_dir: str,
    remote_host: str,
    remote_dir: str,
) -> bool:
    """Transfer job data from on-premise to cloud node."""
    if cfg.method == "s3":
        return _transfer_via_s3(cfg, source_dir, upload=True)
    else:
        return _transfer_via_rsync(cfg, source_dir, remote_host, remote_dir, push=True)


def transfer_from_cloud(
    cfg: TransferConfig,
    remote_host: str,
    remote_dir: str,
    local_dir: str,
) -> bool:
    """Transfer results from cloud node back to on-premise."""
    if cfg.method == "s3":
        return _transfer_via_s3(cfg, local_dir, upload=False)
    else:
        return _transfer_via_rsync(cfg, local_dir, remote_host, remote_dir, push=False)


def _transfer_via_rsync(
    cfg: TransferConfig,
    local_path: str,
    remote_host: str,
    remote_path: str,
    push: bool,
) -> bool:
    """Transfer data using rsync over SSH tunnel."""
    ssh_key = os.path.expanduser(cfg.ssh_key_path)

    ssh_opts = f"-e 'ssh -i {ssh_key} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'"

    cmd = ["rsync", "-avz", "--progress"]

    if cfg.compression:
        cmd.append("--compress")

    if cfg.bandwidth_limit_kbps > 0:
        cmd.append(f"--bwlimit={cfg.bandwidth_limit_kbps}")

    # Delete extraneous files on receiver
    cmd.append("--delete")

    cmd.extend(["--rsh", f"ssh -i {ssh_key} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"])

    remote = f"{cfg.ssh_user}@{remote_host}:{remote_path}"

    if push:
        cmd.extend([f"{local_path}/", remote])
        logger.info(f"rsync push: {local_path} -> {remote}")
    else:
        cmd.extend([remote + "/", local_path])
        logger.info(f"rsync pull: {remote} -> {local_path}")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
        if result.returncode != 0:
            logger.error(f"rsync failed (exit {result.returncode}): {result.stderr}")
            return False
        logger.info("rsync transfer complete")
        return True
    except subprocess.TimeoutExpired:
        logger.error("rsync transfer timed out (1 hour)")
        return False


def _transfer_via_s3(
    cfg: TransferConfig,
    local_path: str,
    upload: bool,
) -> bool:
    """Transfer data using S3 as intermediary."""
    if not cfg.s3_bucket:
        logger.error("S3 bucket not configured")
        return False

    s3 = boto3.client("s3")

    try:
        if upload:
            logger.info(f"Uploading {local_path} to s3://{cfg.s3_bucket}/{cfg.s3_prefix}/")
            _s3_sync_upload(s3, local_path, cfg.s3_bucket, cfg.s3_prefix)
        else:
            logger.info(f"Downloading s3://{cfg.s3_bucket}/{cfg.s3_prefix}/ to {local_path}")
            _s3_sync_download(s3, cfg.s3_bucket, cfg.s3_prefix, local_path)
        return True
    except ClientError as e:
        logger.error(f"S3 transfer failed: {e}")
        return False


def _s3_sync_upload(s3_client, local_dir: str, bucket: str, prefix: str):
    """Upload directory to S3."""
    for root, dirs, files in os.walk(local_dir):
        for fname in files:
            local_file = os.path.join(root, fname)
            rel_path = os.path.relpath(local_file, local_dir)
            s3_key = f"{prefix}/{rel_path}"
            logger.debug(f"Uploading {local_file} -> s3://{bucket}/{s3_key}")
            s3_client.upload_file(local_file, bucket, s3_key)


def _s3_sync_download(s3_client, bucket: str, prefix: str, local_dir: str):
    """Download S3 prefix to local directory."""
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            s3_key = obj["Key"]
            rel_path = os.path.relpath(s3_key, prefix)
            local_file = os.path.join(local_dir, rel_path)
            os.makedirs(os.path.dirname(local_file), exist_ok=True)
            logger.debug(f"Downloading s3://{bucket}/{s3_key} -> {local_file}")
            s3_client.download_file(bucket, s3_key, local_file)


def cleanup_s3(cfg: TransferConfig) -> None:
    """Remove temporary data from S3 after job completion."""
    if not cfg.s3_bucket or cfg.method != "s3":
        return

    s3 = boto3.client("s3")
    logger.info(f"Cleaning up s3://{cfg.s3_bucket}/{cfg.s3_prefix}/")

    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=cfg.s3_bucket, Prefix=cfg.s3_prefix):
        objects = [{"Key": obj["Key"]} for obj in page.get("Contents", [])]
        if objects:
            s3.delete_objects(Bucket=cfg.s3_bucket, Delete={"Objects": objects})

    logger.info("S3 cleanup complete")
