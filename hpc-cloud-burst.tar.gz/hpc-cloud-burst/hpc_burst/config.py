"""
Configuration management for HPC Cloud Burst.
Loads settings from YAML config file and environment variables.
"""

import os
import yaml
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class AWSConfig:
    region: str = "us-east-1"
    ami_id: str = ""                        # AMI with Slurm worker pre-installed
    instance_type: str = "c5.9xlarge"       # Default compute instance
    key_pair: str = ""
    security_group_id: str = ""
    subnet_id: str = ""
    iam_instance_profile: str = ""
    spot_enabled: bool = True               # Use spot instances to save cost
    spot_max_price: str = ""                # Empty = on-demand price cap
    root_volume_size_gb: int = 100
    tags: dict = field(default_factory=lambda: {"Project": "hpc-cloud-burst"})


@dataclass
class SlurmConfig:
    scontrol_path: str = "/usr/bin/scontrol"
    squeue_path: str = "/usr/bin/squeue"
    sinfo_path: str = "/usr/bin/sinfo"
    sbatch_path: str = "/usr/bin/sbatch"
    slurm_conf_dir: str = "/etc/slurm"
    partition_name: str = "cloud"           # Slurm partition for burst nodes
    capacity_threshold: float = 0.85        # Trigger burst at 85% usage


@dataclass
class TransferConfig:
    method: str = "rsync"                   # rsync | s3
    ssh_key_path: str = "~/.ssh/id_rsa"
    ssh_user: str = "ec2-user"
    s3_bucket: str = ""                     # For S3-based transfers
    s3_prefix: str = "hpc-burst-data"
    bandwidth_limit_kbps: int = 0           # 0 = unlimited
    compression: bool = True
    encryption: bool = True                 # SSH tunnel for rsync


@dataclass
class BurstConfig:
    aws: AWSConfig = field(default_factory=AWSConfig)
    slurm: SlurmConfig = field(default_factory=SlurmConfig)
    transfer: TransferConfig = field(default_factory=TransferConfig)
    max_cloud_nodes: int = 10
    teardown_delay_seconds: int = 60        # Wait before destroying cloud nodes
    log_level: str = "INFO"
    state_dir: str = "/var/lib/hpc-burst"   # Persistent state directory


def load_config(config_path: str) -> BurstConfig:
    """Load configuration from YAML file, with env var overrides."""
    cfg = BurstConfig()

    if os.path.exists(config_path):
        with open(config_path) as f:
            data = yaml.safe_load(f) or {}

        aws = data.get("aws", {})
        for k, v in aws.items():
            if hasattr(cfg.aws, k):
                setattr(cfg.aws, k, v)

        slurm = data.get("slurm", {})
        for k, v in slurm.items():
            if hasattr(cfg.slurm, k):
                setattr(cfg.slurm, k, v)

        transfer = data.get("transfer", {})
        for k, v in transfer.items():
            if hasattr(cfg.transfer, k):
                setattr(cfg.transfer, k, v)

        for k in ("max_cloud_nodes", "teardown_delay_seconds", "log_level", "state_dir"):
            if k in data:
                setattr(cfg, k, data[k])
    else:
        logger.warning(f"Config file not found: {config_path}. Using defaults.")

    # Environment variable overrides (higher priority)
    env_map = {
        "HPC_AWS_REGION": ("aws", "region"),
        "HPC_AWS_AMI_ID": ("aws", "ami_id"),
        "HPC_AWS_INSTANCE_TYPE": ("aws", "instance_type"),
        "HPC_AWS_KEY_PAIR": ("aws", "key_pair"),
        "HPC_AWS_SECURITY_GROUP": ("aws", "security_group_id"),
        "HPC_AWS_SUBNET": ("aws", "subnet_id"),
        "HPC_SLURM_THRESHOLD": ("slurm", "capacity_threshold"),
        "HPC_TRANSFER_METHOD": ("transfer", "method"),
        "HPC_S3_BUCKET": ("transfer", "s3_bucket"),
        "HPC_MAX_CLOUD_NODES": (None, "max_cloud_nodes"),
        "HPC_LOG_LEVEL": (None, "log_level"),
    }

    for env_key, (section, attr) in env_map.items():
        val = os.environ.get(env_key)
        if val is not None:
            target = getattr(cfg, section) if section else cfg
            current = getattr(target, attr)
            if isinstance(current, float):
                val = float(val)
            elif isinstance(current, int):
                val = int(val)
            setattr(target, attr, val)

    return cfg
