"""HPC Cloud Burst — Automatically burst Slurm workloads to AWS."""

__version__ = "1.0.0"
