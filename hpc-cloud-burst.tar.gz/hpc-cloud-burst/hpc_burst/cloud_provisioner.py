"""
AWS cloud node provisioner — creates and manages EC2 instances
for Slurm burst workloads using boto3.
"""

import time
import logging
from dataclasses import dataclass
from typing import List, Optional

import boto3
from botocore.exceptions import ClientError

from hpc_burst.config import AWSConfig

logger = logging.getLogger(__name__)


@dataclass
class CloudInstance:
    instance_id: str
    public_ip: str
    private_ip: str
    instance_type: str
    state: str
    launch_time: str


def get_ec2_client(cfg: AWSConfig):
    return boto3.client("ec2", region_name=cfg.region)


def get_ec2_resource(cfg: AWSConfig):
    return boto3.resource("ec2", region_name=cfg.region)


def select_instance_type(required_cpus: int, cfg: AWSConfig) -> str:
    """Select appropriate instance type based on CPU requirements."""
    instance_map = {
        4: "c5.xlarge",
        8: "c5.2xlarge",
        16: "c5.4xlarge",
        36: "c5.9xlarge",
        72: "c5.18xlarge",
        96: "c5.24xlarge",
    }
    for cpus, itype in sorted(instance_map.items()):
        if cpus >= required_cpus:
            return itype
    return cfg.instance_type


def provision_instances(
    cfg: AWSConfig,
    count: int,
    required_cpus_per_node: int,
    job_id: str,
) -> List[CloudInstance]:
    """Provision EC2 instances for burst workload."""

    instance_type = select_instance_type(required_cpus_per_node, cfg)
    logger.info(f"Provisioning {count}x {instance_type} for job {job_id}")

    ec2 = get_ec2_resource(cfg)

    tags = [
        {"Key": k, "Value": v} for k, v in cfg.tags.items()
    ] + [
        {"Key": "Name", "Value": f"hpc-burst-{job_id}"},
        {"Key": "hpc-burst-job", "Value": job_id},
        {"Key": "hpc-burst-managed", "Value": "true"},
    ]

    launch_params = {
        "ImageId": cfg.ami_id,
        "InstanceType": instance_type,
        "MinCount": count,
        "MaxCount": count,
        "KeyName": cfg.key_pair,
        "SecurityGroupIds": [cfg.security_group_id],
        "SubnetId": cfg.subnet_id,
        "TagSpecifications": [
            {"ResourceType": "instance", "Tags": tags}
        ],
        "BlockDeviceMappings": [
            {
                "DeviceName": "/dev/xvda",
                "Ebs": {
                    "VolumeSize": cfg.root_volume_size_gb,
                    "VolumeType": "gp3",
                    "DeleteOnTermination": True,
                },
            }
        ],
    }

    if cfg.iam_instance_profile:
        launch_params["IamInstanceProfile"] = {"Name": cfg.iam_instance_profile}

    # User data: bootstrap Slurm worker
    user_data = _generate_user_data(cfg, job_id)
    launch_params["UserData"] = user_data

    if cfg.spot_enabled:
        launch_params["InstanceMarketOptions"] = {
            "MarketType": "spot",
            "SpotOptions": {
                "SpotInstanceType": "one-time",
                "InstanceInterruptionBehavior": "terminate",
            },
        }
        if cfg.spot_max_price:
            launch_params["InstanceMarketOptions"]["SpotOptions"]["MaxPrice"] = cfg.spot_max_price

    try:
        instances = ec2.create_instances(**launch_params)
    except ClientError as e:
        logger.error(f"Failed to launch instances: {e}")
        raise

    # Wait for instances to be running
    instance_ids = [i.id for i in instances]
    logger.info(f"Waiting for instances to reach 'running' state: {instance_ids}")

    client = get_ec2_client(cfg)
    waiter = client.get_waiter("instance_running")
    waiter.wait(InstanceIds=instance_ids, WaiterConfig={"Delay": 10, "MaxAttempts": 60})

    # Refresh instance data
    result = []
    for inst in instances:
        inst.reload()
        ci = CloudInstance(
            instance_id=inst.id,
            public_ip=inst.public_ip_address or "",
            private_ip=inst.private_ip_address or "",
            instance_type=inst.instance_type,
            state=inst.state["Name"],
            launch_time=str(inst.launch_time),
        )
        result.append(ci)
        logger.info(f"Instance ready: {ci.instance_id} ({ci.public_ip})")

    return result


def wait_for_ssh(instances: List[CloudInstance], timeout: int = 300) -> bool:
    """Wait for SSH to be available on all instances."""
    import socket

    deadline = time.time() + timeout
    for inst in instances:
        ip = inst.public_ip
        while time.time() < deadline:
            try:
                sock = socket.create_connection((ip, 22), timeout=5)
                sock.close()
                logger.info(f"SSH available on {inst.instance_id} ({ip})")
                break
            except (socket.timeout, ConnectionRefusedError, OSError):
                time.sleep(5)
        else:
            logger.error(f"SSH timeout on {inst.instance_id} ({ip})")
            return False
    return True


def terminate_instances(cfg: AWSConfig, instance_ids: List[str]) -> None:
    """Terminate cloud instances after job completion."""
    if not instance_ids:
        return

    client = get_ec2_client(cfg)
    logger.warning(f"Terminating instances: {instance_ids}")

    try:
        client.terminate_instances(InstanceIds=instance_ids)
        waiter = client.get_waiter("instance_terminated")
        waiter.wait(InstanceIds=instance_ids, WaiterConfig={"Delay": 10, "MaxAttempts": 60})
        logger.info(f"All instances terminated: {instance_ids}")
    except ClientError as e:
        logger.error(f"Failed to terminate instances: {e}")
        raise


def find_burst_instances(cfg: AWSConfig, job_id: Optional[str] = None) -> List[str]:
    """Find all running burst instances, optionally filtered by job."""
    client = get_ec2_client(cfg)
    filters = [
        {"Name": "tag:hpc-burst-managed", "Values": ["true"]},
        {"Name": "instance-state-name", "Values": ["running", "pending"]},
    ]
    if job_id:
        filters.append({"Name": "tag:hpc-burst-job", "Values": [job_id]})

    response = client.describe_instances(Filters=filters)
    ids = []
    for res in response.get("Reservations", []):
        for inst in res.get("Instances", []):
            ids.append(inst["InstanceId"])
    return ids


def _generate_user_data(cfg: AWSConfig, job_id: str) -> str:
    """Generate cloud-init user data to configure Slurm worker."""
    return f"""#!/bin/bash
set -euo pipefail
exec > /var/log/hpc-burst-init.log 2>&1

echo "[hpc-burst] Initializing burst node for job {job_id}"

# Update Slurm configuration
cat >> /etc/slurm/slurm.conf << 'SLURM_CONF'
# Cloud burst node configuration — auto-generated
SlurmctldHost=$(hostname -f)
SLURM_CONF

# Start Slurm daemon
systemctl enable slurmd
systemctl start slurmd

# Signal readiness
touch /tmp/hpc-burst-ready
echo "[hpc-burst] Node ready for job {job_id}"
"""
