"""
CLI entry point for HPC Cloud Burst.
"""

import argparse
import sys
import logging

from hpc_burst.orchestrator import BurstOrchestrator


def main():
    parser = argparse.ArgumentParser(
        description="HPC Cloud Burst — Auto-scale Slurm workloads to AWS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start the monitor daemon
  hpc-burst monitor --config /etc/hpc-burst/config.yaml

  # Burst a specific job
  hpc-burst burst --job-id 12345

  # Emergency cleanup
  hpc-burst cleanup

  # Show cluster status
  hpc-burst status
        """,
    )

    parser.add_argument(
        "--config", "-c",
        default="/etc/hpc-burst/config.yaml",
        help="Path to config file",
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # monitor
    mon = subparsers.add_parser("monitor", help="Start burst monitor daemon")
    mon.add_argument("--interval", type=int, default=30, help="Poll interval (seconds)")

    # burst
    burst = subparsers.add_parser("burst", help="Burst a specific job to cloud")
    burst.add_argument("--job-id", required=True, help="Slurm job ID to burst")

    # cleanup
    subparsers.add_parser("cleanup", help="Terminate all burst instances")

    # status
    subparsers.add_parser("status", help="Show cluster and burst status")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    orch = BurstOrchestrator(config_path=args.config)

    if args.command == "monitor":
        orch.run_monitor_loop(poll_interval=args.interval)

    elif args.command == "burst":
        success = orch.burst_job(args.job_id)
        sys.exit(0 if success else 1)

    elif args.command == "cleanup":
        orch.cleanup_all()

    elif args.command == "status":
        from hpc_burst.slurm_monitor import get_cluster_status
        from hpc_burst.cloud_provisioner import find_burst_instances
        status = get_cluster_status(orch.cfg.slurm)
        cloud_ids = find_burst_instances(orch.cfg.aws)
        print(f"On-Prem: {status.used_cores}/{status.total_cores} cores ({status.utilization:.0%})")
        print(f"Running: {status.running_jobs} | Pending: {status.pending_jobs}")
        print(f"Cloud burst nodes: {len(cloud_ids)}")
        if cloud_ids:
            for cid in cloud_ids:
                print(f"  - {cid}")


if __name__ == "__main__":
    main()
