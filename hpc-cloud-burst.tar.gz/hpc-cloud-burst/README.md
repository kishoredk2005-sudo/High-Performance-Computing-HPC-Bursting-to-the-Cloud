# HPC Cloud Burst

Python automation to burst Slurm HPC workloads to AWS when on-premise capacity is full.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  ON-PREMISE CLUSTER                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ Slurm    │  │ Compute  │  │ Burst Monitor    │  │
│  │ Controller│  │ Nodes    │  │ (hpc-burst)      │  │
│  └──────────┘  └──────────┘  └────────┬─────────┘  │
└───────────────────────────────────────┼─────────────┘
                                        │
                     Capacity > 85%?    │
                     Pending jobs?      │
                                        ▼
┌─────────────────────────────────────────────────────┐
│                    AWS CLOUD                         │
│                                                      │
│  1. Provision EC2 (boto3)    ──► c5.xlarge-24xlarge  │
│  2. Configure Slurm worker   ──► cloud-init          │
│  3. rsync data (SSH tunnel)  ──► encrypted transfer  │
│  4. Execute job              ──► sbatch / direct     │
│  5. Return results (rsync)   ──► back to on-prem     │
│  6. Terminate instances      ──► auto teardown       │
│                                                      │
└─────────────────────────────────────────────────────┘
```

## Lifecycle

1. **Monitor** — Polls Slurm (`sinfo`/`squeue`) every 30s
2. **Detect** — Triggers burst when utilization ≥ 85% AND pending jobs exist
3. **Provision** — Launches EC2 spot instances via boto3 with cloud-init
4. **Transfer** — Securely moves data via rsync/SSH or S3
5. **Execute** — Runs the job on cloud nodes (Slurm or direct)
6. **Return** — Transfers results back to on-premise storage
7. **Teardown** — Terminates all cloud resources, cleans up S3

## Installation

```bash
pip install -e .
```

## Configuration

```bash
cp config.example.yaml /etc/hpc-burst/config.yaml
# Edit with your AWS credentials, AMI, VPC settings
```

### Environment variable overrides

| Variable | Overrides |
|----------|-----------|
| `HPC_AWS_REGION` | `aws.region` |
| `HPC_AWS_AMI_ID` | `aws.ami_id` |
| `HPC_AWS_INSTANCE_TYPE` | `aws.instance_type` |
| `HPC_AWS_KEY_PAIR` | `aws.key_pair` |
| `HPC_AWS_SECURITY_GROUP` | `aws.security_group_id` |
| `HPC_AWS_SUBNET` | `aws.subnet_id` |
| `HPC_SLURM_THRESHOLD` | `slurm.capacity_threshold` |
| `HPC_TRANSFER_METHOD` | `transfer.method` |
| `HPC_S3_BUCKET` | `transfer.s3_bucket` |
| `HPC_MAX_CLOUD_NODES` | `max_cloud_nodes` |

## Usage

```bash
# Start continuous monitor (daemon mode)
hpc-burst monitor --config /etc/hpc-burst/config.yaml --interval 30

# Burst a specific pending job
hpc-burst burst --job-id 12345

# Check cluster & burst status
hpc-burst status

# Emergency: terminate ALL cloud burst instances
hpc-burst cleanup
```

## Prerequisites

- **On-premise**: Slurm cluster with `sinfo`, `squeue`, `scontrol`, `sbatch`
- **AWS**: Account with EC2, (optional) S3 permissions
- **AMI**: Pre-built AMI with Slurm worker daemon, matching Slurm version
- **Network**: SSH access from on-prem to AWS VPC (VPN or public IPs)
- **Python**: 3.9+

## Security

- All data transfers encrypted via SSH tunnel (rsync) or S3 server-side encryption
- Spot instances reduce cost by up to 90%
- Cloud resources auto-terminate after job completion
- State persisted to disk for crash recovery
- IAM instance profiles for least-privilege access

## Module Structure

```
hpc_burst/
├── __init__.py          # Package init
├── config.py            # YAML + env config loading
├── slurm_monitor.py     # Slurm cluster monitoring
├── cloud_provisioner.py # EC2 instance lifecycle
├── data_transfer.py     # rsync/S3 data movement
├── job_runner.py        # Remote job execution
├── orchestrator.py      # Full lifecycle coordinator
└── cli.py               # CLI entry point
```
